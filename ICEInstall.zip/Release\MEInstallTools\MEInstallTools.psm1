
# -------------------------- Load Script Files ----------------------------
#
# Do not add Export-ModuleMember logic. All functions in .\Public are added to the manifest during build.
# If you need to import from \src\ run the build.ps1 in \tools\ with 'ExportFunctionsToSrc' as the task.
#
$ModuleScriptFiles = @(Get-ChildItem -Path $PSScriptRoot -Filter *.ps1 -Recurse  | Where-Object { $_.Name -notlike "*.ps1xml" } )

foreach ($ScriptFile in $ModuleScriptFiles) {
    try {
       Write-Verbose "Loading script file $($ScriptFile.Name)"
        . $ScriptFile.FullName
    }
    catch {
       Write-Error "Error loading script file $($ScriptFile.FullName)"
    }
}
<#
.SYNOPSIS
Function to return the download folder

.DESCRIPTION
Function to return the download folder since it is not a standard well known folder

.EXAMPLE
Get-DownloadFolder

.NOTES
Author: Mark Evans
General notes
#>
function Get-DownloadFolder {
    Get-KnownFolderPath -KnownFolder 'Downloads'
}
function Get-Installer {

        [CmdletBinding()]
    param (
        [uri]
        $URI,
        [string]
        $DownloadPath = (Get-DownloadFolder)
    )
    $temp = [System.IO.Path]::GetTempFileName()
    $x = Invoke-WebRequest -Uri $URI -PassThru -OutFile $temp -UseBasicParsing
    $name = $x.BaseResponse.ResponseUri.Segments | Select-Object -Last 1
    $Result = (Join-Path $DownloadPath $name)
    move-item $temp $Result -Force
    $Result = Get-ChildItem $Result
    $Downloaded = Get-Version $Result
    Write-Verbose "Download:`t$Name`t$($Downloaded.ProductName)`t$($Downloaded.Version)"
    Return $Result
}
function Get-SharepointFolder {
    [OutputType("System.Collections.ArrayList")]
    [CmdletBinding()]
    param (
        [uri]
        $SiteURI,
        [String]
        $DocumentFolder = 'Shared Documents'
    )
    $URI = [uri]$SiteURI
    #$Strings = $URI.PathAndQuery -split '/'
    #If ($Strings.Count -gt)
    #$Site = "$($Strings[1])/$($Strings[2])"
    $SharePointSite = "$($URI.Scheme)://$($URI.DnsSafeHost)/$($URI.PathAndQuery)"
    Write-Verbose $SharePointSite
    $Stoploop = $false
    [int]$Retrycount = "0"
    $x = CredMan -GetCred -Target "$($URI.Scheme)://$($URI.DnsSafeHost)/"
    if (!($x)) {Write-Output "Credentials for Sharepoint Site $($URI.Scheme)://$($URI.DnsSafeHost)/"}

    do {
        try {
            Connect-PnPOnline -Url $SharePointSite
            $Stoploop = $true
        }
        catch {
            $Retry = (
                $Retrycount -lt 3 -and
                $PSItem.CategoryInfo.Activity -eq 'Connect-PnPOnline' -and
                (
                    $PSItem.CategoryInfo.Reason -eq 'IdcrlException' -or
                    ($PSItem.CategoryInfo.Reason -eq 'WebException' -and $PSItem.Exception.Message -like '*(403)*')
                ))
            if ($Retry) {
                if ($x) {
                    credman -DelCred -Target "$($URI.Scheme)://$($URI.DnsSafeHost)/"
                }
                Write-Error $PSItem.Exception.Message
                Write-Output "Please enter credentials for Sharepoint Site $($URI.Scheme)://$($URI.DnsSafeHost)/"
                Start-Sleep -Seconds 1
                $Retrycount++
            }
            else {
                throw
            }
        }
    }
    While ($Stoploop -eq $false)
    $Files = Get-PnPFolderItem $DocumentFolder -ItemType File -Recursive
    $Result = New-Object -TypeName "System.Collections.ArrayList"
    $DownloadFolder = Get-DownloadFolder
    foreach ($file in $files) {
        IF (!($file.Name.EndsWith('.aspx'))) {
            Get-PnPFile -Url $file.ServerRelativeURL -AsFile -Force -Path ($DownloadFolder)
            $Result.Add((Get-ChildItem (Join-Path $DownloadFolder $file.Name ))) | Out-Null
        }
    }
    Disconnect-PnPOnline
    $Result
}
function Get-Version {
    param (
        [Parameter(Position = 0, Mandatory = $true, ParameterSetName = "FileItem")]
        [IO.FileInfo] $File,
        [Parameter(Position = 0, Mandatory = $true, ParameterSetName = "FileName")]
        [string] $FilleName
    )
    if ($PSCmdlet.ParameterSetName -eq "FileName") {
        $File = Get-ChildItem $FilleName
    }
    If ($File.Extension -eq '.msi') {
        Return Get-MSIVersion -MSI $File
    }
    else {
        Return @{Version = $File.VersionInfo.ProductVersion; ProductName = $File.VersionInfo.ProductName }
    }

}

function Install-Software {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param (
        $Source
    )
    $Package = Get-Version $Source | Select -Last 1
    If (!($Package.Version)){
        throw "Package $($Source.Name) does not have package version"
    }
    $Pattern = '\bv?[0-9]+\.[0-9]+\.[0-9]+(?:\.[0-9]+)?\b'
    $New = ''
    $strReplace = [regex]::Replace($Package.ProductName, $Pattern, $New) + '*'
    $Installed = Get-Package $strReplace -ErrorAction SilentlyContinue
    if (!($Installed)) {
        if ($PSCmdlet.ShouldProcess("$($Package.Name)", "Installing")) {
            Write-Verbose "Installing $($Package.Name)"
            $result = Install-Package $Source | Out-Null
        }
    }
    elseif ([version]$Installed.Version -lt [version]$Package.Version) {
        if ($PSCmdlet.ShouldProcess("$($Package.ProductName)", "Upgrading")) {
            Write-Verbose "Upgrading $($Package.ProductName)"
            Write-Verbose "Installed $($Installed.Version)"
            Write-Verbose "New Version $($Package.Version)"
            $result = Install-Package $Source
        }
    }
    else {
        Write-Verbose "Package $($Package.ProductName) Already Installed"
        Write-Verbose "Installed $($Installed.Version)"
    }
    $result | Out-Null
}
<#
.SYNOPSIS
    Demonstrates how to write a command that works with paths that do
    not allow wildards and do not have to exist.
.DESCRIPTION
    This command does not require a LiteralPath parameter because the
    Path parameter can handle paths that use wildcard characters.  That's
    because this command does not "resolve" the supplied path. This command
    also does not verify the path exists because the point of the command is
    to create a new file at the specified path.
.EXAMPLE
    C:\PS> New-File -Path xyzzy[1].txt -WhatIf
    This example shows how the Path parameter can handle a path that happens
    to use the wildcard chars "[" and "]" and does not exist to start with.
.NOTES
Author: Mark Evans
#>
function New-File {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        # Specifies a path to one or more locations.
        [Parameter(Mandatory = $true,
            Position = 0,
            ParameterSetName = "Path",
            ValueFromPipeline = $true,
            ValueFromPipelineByPropertyName = $true,
            HelpMessage = "Path to one or more locations.")]
        [Alias("PSPath")]
        [ValidateNotNullOrEmpty()]
        [string[]]
        $Path
    )

    begin {
        Write-Verbose -Message "Starting $($MyInvocation.InvocationName) with $($PsCmdlet.ParameterSetName) parameterset..."
    } # begin

    process {
        # Modify [CmdletBinding()] to [CmdletBinding(SupportsShouldProcess=$true)]
        $paths = @()
        foreach ($aPath in $Path) {
            # Resolve any relative paths
            $paths += $psCmdlet.SessionState.Path.GetUnresolvedProviderPathFromPSPath($aPath)
        }

        foreach ($aPath in $paths) {
            if ($pscmdlet.ShouldProcess($aPath, 'Operation')) {
                # Process each path
                try {
                    $Result = Operation $aPath
                }
                catch {
                    $Result = False
                }
                # Return Result
                # Generate Complex Output
                New-Object -TypeName PSObject -Property @{
                    Result = $Result
                    Object = $aPath
                }
            }
        }
    } # process

    end {
        Write-Verbose -Message "Ending $($MyInvocation.InvocationName)..."
    } # end
}
#Get-ChildItem 'C:\MNP\' | Select-Object -ExpandProperty FullName | New-File -Verbose
function Set-ODBCConnection {
        [CmdletBinding(SupportsShouldProcess)]
    param (
        $DBName,
        $ServerInstance,
        $DSNType
    )
    If (!($DSNType)) {
        $DSNType = If (Test-IsAdmin) {
            'System'
        }
        else {
            'User'
        }
    }
    $HashArguments = @{
        Name             = "$DBName"
        DriverName       = "SQL Server Native Client 11.0"
        SetPropertyValue = @("Server=$($ServerInstance)",
            "Trusted_Connection=No",
            "Database=$DBName")
        DsnType          = $DSNType
    }
    if ($PSCmdlet.ShouldProcess("ODBC Connection $DBName", "Create")) {
        if (!(Get-OdbcDsn -Name $DBName -ea SilentlyContinue -Platform '32-Bit')) {
            Add-OdbcDsn @HashArguments -Platform '32-bit'
        }
        if (!(Get-OdbcDsn -Name $DBName -ea SilentlyContinue -Platform '64-Bit')) {
            Add-OdbcDsn @HashArguments -Platform '64-bit'
        }
    }
}

function New-Shortcut {
    [CmdletBinding(SupportsShouldProcess)]
    param (
        [System.IO.FileInfo]
        [Parameter(Position = 0, Mandatory = $true, ParameterSetName = "Item")]
        [IO.FileInfo] $Target,
        [Parameter(Position = 0, Mandatory = $true, ParameterSetName = "Name")]
        [string] $TargetPath,
        [String]
        $ShortcutName,
        [String]
        $ShortcutFolder,
        [switch]
        $Desktop,
        [switch]
        $AllUsers
    )
    if ($PSCmdlet.ParameterSetName -eq "Item") {
        $TargetPath = Get-ChildItem $Target.FullName
    }
    if (!(Test-Path -Path $TargetPath -PathType Leaf)) {
        throw [System.IO.FileNotFoundException] "$TargetPath not found."
    }
    if ($PSCmdlet.ParameterSetName -eq 'Name') {
        $Target = Get-ChildItem $TargetPath
    }
    if (!($ShortcutName)) {
        $ShortcutName = $Target.BaseName
    }
    if (!($ShortcutName.EndsWith('.lnk'))) { $ShortcutName += '.lnk' }

    if ($AllUsers) {
        if ($Desktop) {
            $ShortcutRoot = [Environment]::GetFolderPath([System.Environment+SpecialFolder]::CommonDesktopDirectory)
        }
        else {
            $ShortcutRoot = [Environment]::GetFolderPath([System.Environment+SpecialFolder]::CommonStartMenu)
        }
    }
    else {
        if ($Desktop) {
            $ShortcutRoot = [Environment]::GetFolderPath([System.Environment+SpecialFolder]::DesktopDirectory)
        }
        else {
            $ShortcutRoot = [Environment]::GetFolderPath([System.Environment+SpecialFolder]::StartMenu)
        }
    }
    If (!($Desktop)){
        $ShortcutRoot = Join-Path $ShortcutRoot 'Programs'
    }
    if ($ShortcutFolder) {
        $ShortcutRoot = Join-Path $ShortcutRoot $ShortcutFolder
        New-Item -Path $ShortcutRoot -ItemType Directory -Force | Out-Null
    }
    $ShortcutLink = Join-Path $ShortcutRoot $ShortcutName

    if ($PSCmdlet.ShouldProcess("$ShortcutLink", "Create")) {
        $WshShell = New-Object -comObject WScript.Shell
        $Shortcut = $WshShell.CreateShortcut($ShortcutLink)
        $Shortcut.TargetPath = $TargetPath
        $Shortcut.Save()
        return (Get-ChildItem $ShortcutLink)
    }
    return
}
function New-StartTile {
    [CmdletBinding(SupportsShouldProcess)]
    param (
        $Group,
        [System.IO.FileInfo]
        [Parameter(Mandatory = $true, ParameterSetName = "Item")]
        $Shortcut
    )


    if (!(Test-IsAdmin) ) {
        throw "This function requires elevation."
    }
    $ShortcutName = Set-ShortcutCase($Shortcut.Name)

    if (Get-Command Export-StartLayout) {
        # export current start layout to temporary file
        $tmp = New-TemporaryFile
        Export-StartLayout -Path $tmp.FullName

        # load start menu xml for manipulation
        $xml = New-Object -TypeName 'XML'
        $xml.Load($tmp.FullName)
        Remove-Item -Path $tmp.FullName

        $LayoutNode = $xml.DocumentElement.SelectSingleNode('//*[local-name()="StartLayout"]')
        $LayoutWidth = $LayoutNode.GroupCellWidth / 2
        # find existing Group
        $GroupNode = $xml.DocumentElement.SelectNodes("//*[local-name()=""Group"" and @Name=""$Group""]")
        # create group if it doesn't exist
        if (!($GroupNode) -or $GroupNode.Count -eq 0) {
            Write-Verbose "Creating Group Node"
            $GroupNodes = $xml.DocumentElement.SelectNodes('//*[local-name()="Group"]')
            $GroupNode = $GroupNodes[0].Clone()
            $GroupNode.RemoveAll()
            $GroupNode.SetAttribute("Name", $Group)
            $LayoutNode.PrependChild($GroupNode)
        }
        else {
            Write-Verbose "Group Node Exists"
        }
        # find existing Node
        # $DesktopApplicationTileNode = `
        #    $GroupNode.SelectNodes(".//*[substring(@DesktopApplicationLinkPath, string-length(@DesktopApplicationLinkPath)-string-length(""$ShortcutName"") +1)=""$ShortcutName"" ]")
        $DesktopApplicationTileNode = $GroupNode.SelectNodes(".//*") | Where-Object { $_.DesktopApplicationLinkPath.tolower().endswith($ShortcutName.ToLower()) } | Select -First 1
        # create if it doesn't exist
        If (!($DesktopApplicationTileNode) -or $DesktopApplicationTileNode.Count -eq 0) {
            Write-Verbose "Application Node Found"
            $GroupAppNodes = $GroupNode.SelectNodes('.//*')
            $Count = ($GroupAppNodes | Measure-Object | Select-Object -ExpandProperty Count)
            $Row = [Int]([Math]::Floor($Count / $LayoutWidth)) * 2
            $Col = [Int](($Count % $LayoutWidth)) * 2
            $DesktopApplicationTileNodes = $xml.DocumentElement.SelectNodes('//*[local-name()="DesktopApplicationTile"]')
            $DesktopApplicationTileNode = $DesktopApplicationTileNodes[0].Clone()
            $DesktopApplicationTileNode.RemoveAll()
            $DesktopApplicationTileNode.SetAttribute("Size", "2x2")
            $DesktopApplicationTileNode.SetAttribute("Column", "$Col")
            $DesktopApplicationTileNode.SetAttribute("Row", "$Row")
            $DesktopApplicationTileNode.SetAttribute("DesktopApplicationLinkPath", $Shortcut.FullName)
            $GroupNode.AppendChild($DesktopApplicationTileNode)
        }
        else {
            Write-Verbose "Updating existing application Node"
            $DesktopApplicationTileNode.SetAttribute("DesktopApplicationLinkPath", $Shortcut.FullName)
        }
        $xml.Save("$($tmp.FullName).xml")
        Import-StartLayout -LayoutPath "$($tmp.FullName).xml" -MountPath C:\
        #if (!($?)) { notepad "$($tmp.FullName).xml" }
        New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows -Name Explorer -ErrorAction SilentlyContinue
        Reg Add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer" /V LockedStartLayout /T REG_DWORD /D 1 /F | Out-Null
        Reg Add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer" /V StartLayoutFile /T REG_EXPAND_SZ /D "$($tmp.FullName).xml" /F | Out-Null
        $explorerProcess = Stop-Process -ProcessName explorer -force -PassThru
        Wait-Process -Id $explorerProcess.Id -ErrorAction Ignore
        #while ( !(Get-Process -Name explorer -ErrorAction SilentlyContinue) ) {
        #    Write-Host '.' -NoNewline
        #    Start-Sleep -Milliseconds 10
        #}
        # wait for explorer to start
        Start-Sleep -Milliseconds 500
        $i = 0
        while (!(Get-Process -Name explorer -ErrorAction SilentlyContinue)) {
            Write-Progress -Activity 'Restarting Explorer' -PercentComplete -1
            Start-Sleep -Milliseconds 10;
            $i++
            if ($i -gt 50){
                Start-Process 'explorer'
            }
        }
        # wait for explorer to stop processing
        while ((Get-Process -Name explorer).threads | Where-Object { $_.ThreadState -eq 'Running' }) {
            start-sleep -Milliseconds 10;
            Write-Progress -Activity 'Restarting Explorer' -PercentComplete -1
        }
        Write-Progress -Activity 'Restarting Explorer' -Completed

        #while ((Get-Process -Name explorer -ErrorAction SilentlyContinue).StartTime.AddMilliseconds(500) -gt (Get-Date) ){
        #    Write-Host '*' -NoNewline
        #    Start-Sleep -Milliseconds 10
        #}


        #Start-Sleep -s 10

        #sleep is to let explorer finish restart b4 deleting reg keys
        Remove-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer" -Name "LockedStartLayout" -Force
        Remove-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer" -Name "StartLayoutFile" -Force
        Stop-Process -ProcessName explorer -force
        Remove-Item "$($tmp.FullName).xml" -Force -ErrorAction Ignore
        $i = 0
        while (!(Get-Process -Name explorer -ErrorAction SilentlyContinue)) {
            Write-Host '*' -NoNewline
            Start-Sleep -Milliseconds 10;
            $i++
            if ($i -gt 50){
                Start-Process 'explorer'
            }
        }

    }
}
function Read-ScriptParameters {
    [CmdletBinding()]
    param (
        [Parameter()]
        $ScriptParameters,
        [Parameter()]
        $BoundParameters
    )
    $ScriptParams = @{}
    $ScriptParameters.GetEnumerator() | Where-Object {$_.Key -notin ([System.Management.Automation.Cmdlet]::CommonParameters) } | ForEach-Object { $ScriptParams.Add($_.Key, $_.Value) }
    Write-Verbose "ScriptHas $($ScriptParams.Count)"
    if ($BoundParameters.Keys.Count -gt 0) {
        $UnsetParams = Compare-Object -ReferenceObject $($ScriptParams.Keys) -DifferenceObject $($PSBoundParameters.Keys)
    }
    else {
        $UnsetParams = (Compare-Object -ReferenceObject $($ScriptParams.Keys) -DifferenceObject (@{v123p32 = "" }).Keys | Where-Object { $_.SideIndicator -eq '<=' })
    }
    foreach ($item in $UnsetParams) {
        $Param = $ScriptParams[$item.InputObject]
        $value = $null
        $Message = $Param.Attributes[0].HelpMessage
        $default = (Get-Variable -Name $item.InputObject -Scope $Global).Value
        if (!($value = Read-Host "$Message [$default]")) { $value = $default }
        Set-Variable -Name $item.InputObject -Value $value -Scope Global
    }
}
#Adapted from https://gist.github.com/altrive/5329377
#Based on <http://gallery.technet.microsoft.com/scriptcenter/Get-PendingReboot-Query-bdb79542>
#Adapted to use CIM based on https://www.reddit.com/r/SCCM/comments/b3r7n4/can_you_change_the_pending_reboot_time_on_a_sccm/
function Test-PendingReboot {
    if (Get-ChildItem "HKLM:\Software\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending" -EA Ignore) { return $true }
    if (Get-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired" -EA Ignore) { return $true }
    if (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager" -Name PendingFileRenameOperations -EA Ignore) { return $true }
    if (Invoke-CimMethod -Namespace root/ccm/ClientSDK -ClassName CCM_ClientUtilities -MethodName DetermineIfRebootPending -ea silentlycontinu) {return $true}
    return $false
}
Function Wait-FileUnlock{
    Param(
        [Parameter()]
        [IO.FileInfo]$File,
        [int]$SleepInterval=500
    )
    while(1){
        try{
           $fs=$file.Open('open','read', 'Read')
           $fs.Close()
            Write-Verbose "$file not open"
           return
           }
        catch{
           Start-Sleep -Milliseconds $SleepInterval
           Write-Verbose '-'
        }
	}
}
